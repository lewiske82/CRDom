# CRDom Mini CRM

Mini CRM-szeru ugyfel-nyilvantarto es utanakoveto rendszer harom szintu admin felulettel es tobbszintes audit agent-ekkel.

## Fobb funkciok
- Fő Admin (SUPER_ADMIN): halozatok (tenant-ek) letrehozasa, felhasznalok kezelese, globalis audit attekintes.
- Tenant Admin (TENANT_ADMIN): sajat halozati userek kezelese, ugyfelek kezelese, audit naplo.
- User: sajat ugyfelek, utanakovetes, interakciok rogzitese.
- Egyedi szerepkorok: uj szintek hozhatok letre jogokkal (role permissions), es meglvo user felminositheto.
- Regisztracio: telefonszam kotelezo, orszag szerinti validacioval (libphonenumber).
- Apple ID es Google SSO (OAuth flow), beallitasok admin feluleten.
- Audit export CSV/JSON formaban (globalis es tenant szinten).
- Audit agent-ek: L1 adatminoseg, L2 jogosultsag, L3 kockazati pontszam.

## Telepites (macOS)

```bash
npm install
cp .env.example .env
npm run dev
```

Alapertelmezetten:
- A super admin felhasznalonev: `domoslaszlokrisztian@gmail.com`
- Jelszo: `SUPER_ADMIN_PASSWORD` a `.env`-ben (ha nincs beallitva, ideiglenes alap jelszo jon letre).

A rendszer a `data/crdom.sqlite` SQLite adatbazist hasznalja.

## SSO (OAuth)
- Fő Admin -> SSO oldalon add meg a provider kulcsokat.
- Callback URL-ek:
  - Google: `BASE_URL/auth/google/callback`
  - Apple: `BASE_URL/auth/apple/callback`
- Ha `BASE_URL` nincs megadva, a request hostja alapjan epul fel.

## Szerepkorok
- SUPER_ADMIN: osszes tenant es audit esemeny, minden felhasznalo letrehozasa.
- TENANT_ADMIN: sajat halozat userei, ugyfelek, audit.
- USER: sajat ugyfelek, interakciok, utanakovetes.
- Custom role-ok: `ADMIN -> Szintek` menuben hozhatok letre es szerkeszthetok.

## SSO
Az Apple ID es Google SSO konfiguracio a `Fő Admin -> SSO` oldalon rogzitve van. Az OAuth flow implementacioja placeholder, kulon fejlesztendo.

## Struktura
- `src/server.js` - szerver es route-ok
- `src/db.js` - SQLite schema + super admin seed
- `src/audit.js` - audit agent-ek
- `views/` - EJS sablonok
- `public/` - statikus stilusok

## Megjegyzes
Ez egy minimalis referencia implementacio. Termelesi hasznalathoz javasolt:
- biztonsagos session tarolo (pl. Redis)
- rate limiting, CSRF vedelem
- jelszo reset es 2FA
