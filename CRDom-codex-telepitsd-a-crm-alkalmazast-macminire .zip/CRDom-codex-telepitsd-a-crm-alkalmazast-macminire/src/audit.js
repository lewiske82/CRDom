const { ACTION_PERMISSIONS } = require('./permissions');

const AGENTS = [
  {
    name: 'IntegrityAgent',
    tier: 1,
    run: (event) => {
      const issues = [];
      if (event.action.startsWith('CUSTOMER_')) {
        const payload = event.after || event.data || {};
        if (!payload.name) issues.push('Ugyfel nev hianyzik');
        if (!payload.email && !payload.phone) issues.push('Nincs email vagy telefonszam');
      }

      return issues.length
        ? {
            status: 'FLAG',
            severity: 'MEDIUM',
            summary: 'Adatminosegi hianyossag',
            details: { issues },
          }
        : {
            status: 'PASS',
            severity: 'LOW',
            summary: 'Adatminoseg rendben',
            details: { issues: [] },
          };
    },
  },
  {
    name: 'PolicyAgent',
    tier: 2,
    run: (event, context) => {
      const required = ACTION_PERMISSIONS[event.action] || [];
      const rolePermissions = context.rolePermissions || [];
      const ok = required.length === 0 || required.some((permission) => rolePermissions.includes(permission));
      return ok
        ? {
            status: 'PASS',
            severity: 'LOW',
            summary: 'Jogosultsag megfelelo',
            details: { required },
          }
        : {
            status: 'FLAG',
            severity: 'HIGH',
            summary: 'Jogosultsagi elteres',
            details: { required, actorRole: event.actorRole },
          };
    },
  },
  {
    name: 'RiskAgent',
    tier: 3,
    run: (event) => {
      let score = 0;
      const payload = event.after || event.data || {};
      if (!payload.email) score += 20;
      if (!payload.phone) score += 10;
      if (!payload.next_followup_at) score += 20;
      if (payload.status === 'at_risk') score += 30;
      if (payload.status === 'lost') score += 40;

      let severity = 'LOW';
      if (score >= 70) severity = 'HIGH';
      else if (score >= 40) severity = 'MEDIUM';

      return {
        status: severity === 'LOW' ? 'INFO' : 'FLAG',
        severity,
        summary: 'Kockazati pontszam',
        details: { score },
      };
    },
  },
];

function recordAudit(db, event) {
  const stmt = db.prepare(
    `INSERT INTO audit_events (tenant_id, entity_type, entity_id, action, actor_user_id, actor_role, data_json)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  );

  const info = stmt.run(
    event.tenantId || null,
    event.entityType,
    event.entityId,
    event.action,
    event.actorUserId || null,
    event.actorRole || null,
    JSON.stringify({
      data: event.data || null,
      before: event.before || null,
      after: event.after || null,
    })
  );

  const auditEventId = info.lastInsertRowid;
  const findingsStmt = db.prepare(
    `INSERT INTO audit_findings (audit_event_id, agent, tier, status, severity, summary, details_json)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  );

  const rolePermissions = getRolePermissions(db, event.actorRole);
  for (const agent of AGENTS) {
    const result = agent.run(event, { rolePermissions });
    findingsStmt.run(
      auditEventId,
      agent.name,
      agent.tier,
      result.status,
      result.severity,
      result.summary,
      JSON.stringify(result.details || {})
    );
  }

  return auditEventId;
}

function getRolePermissions(db, roleName) {
  if (!roleName) return [];
  const rows = db
    .prepare(
      `SELECT permission_key FROM role_permissions
       WHERE role_name = ?`
    )
    .all(roleName);
  return rows.map((row) => row.permission_key);
}

module.exports = {
  recordAudit,
};
