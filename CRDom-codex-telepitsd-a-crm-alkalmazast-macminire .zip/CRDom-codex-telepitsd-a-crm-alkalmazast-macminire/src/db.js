const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const { hashPassword } = require('./auth');
const { PERMISSIONS, DEFAULT_ROLES } = require('./permissions');

function initDb() {
  const dbPath = process.env.DB_PATH || path.join(process.cwd(), 'data', 'crdom.sqlite');
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });

  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');

  db.exec(`
    CREATE TABLE IF NOT EXISTS tenants (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      role TEXT NOT NULL,
      tenant_id INTEGER,
      password_hash TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (tenant_id) REFERENCES tenants(id)
    );

    CREATE TABLE IF NOT EXISTS roles (
      name TEXT PRIMARY KEY,
      label TEXT NOT NULL,
      is_system INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS permissions (
      key TEXT PRIMARY KEY,
      label TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS role_permissions (
      role_name TEXT NOT NULL,
      permission_key TEXT NOT NULL,
      PRIMARY KEY (role_name, permission_key),
      FOREIGN KEY (role_name) REFERENCES roles(name),
      FOREIGN KEY (permission_key) REFERENCES permissions(key)
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    CREATE TABLE IF NOT EXISTS oauth_accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      provider TEXT NOT NULL,
      subject TEXT NOT NULL,
      user_id INTEGER NOT NULL,
      email TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (provider, subject),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tenant_id INTEGER NOT NULL,
      owner_user_id INTEGER,
      name TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      status TEXT NOT NULL DEFAULT 'new',
      next_followup_at TEXT,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (tenant_id) REFERENCES tenants(id),
      FOREIGN KEY (owner_user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS interactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      type TEXT NOT NULL,
      note TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (customer_id) REFERENCES customers(id),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS audit_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tenant_id INTEGER,
      entity_type TEXT NOT NULL,
      entity_id INTEGER NOT NULL,
      action TEXT NOT NULL,
      actor_user_id INTEGER,
      actor_role TEXT,
      data_json TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (tenant_id) REFERENCES tenants(id),
      FOREIGN KEY (actor_user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS audit_findings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      audit_event_id INTEGER NOT NULL,
      agent TEXT NOT NULL,
      tier INTEGER NOT NULL,
      status TEXT NOT NULL,
      severity TEXT NOT NULL,
      summary TEXT NOT NULL,
      details_json TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (audit_event_id) REFERENCES audit_events(id)
    );
  `);

  ensureColumn(db, 'users', 'phone_country', "TEXT");
  ensureColumn(db, 'users', 'phone_number', "TEXT");

  seedPermissions(db);
  seedDefaultRoles(db);
  ensureSuperAdmin(db);
  return db;
}

function ensureColumn(db, table, column, type) {
  const columns = db.prepare(`PRAGMA table_info(${table})`).all();
  const exists = columns.some((col) => col.name === column);
  if (!exists) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${type}`);
  }
}

function seedPermissions(db) {
  const insert = db.prepare('INSERT OR IGNORE INTO permissions (key, label) VALUES (?, ?)');
  for (const permission of PERMISSIONS) {
    insert.run(permission.key, permission.label);
  }
}

function seedDefaultRoles(db) {
  const insertRole = db.prepare('INSERT OR IGNORE INTO roles (name, label, is_system) VALUES (?, ?, ?)');
  const insertRolePermission = db.prepare(
    'INSERT OR IGNORE INTO role_permissions (role_name, permission_key) VALUES (?, ?)'
  );

  for (const role of DEFAULT_ROLES) {
    insertRole.run(role.name, role.label, role.isSystem);
    for (const permission of role.permissions) {
      insertRolePermission.run(role.name, permission);
    }
  }
}

function ensureSuperAdmin(db) {
  const email = process.env.SUPER_ADMIN_EMAIL || 'domoslaszlokrisztian@gmail.com';
  const password = process.env.SUPER_ADMIN_PASSWORD || 'ChangeMeNow!123';

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    return;
  }

  const passwordHash = hashPassword(password);
  db.prepare(
    'INSERT INTO users (email, name, role, tenant_id, password_hash) VALUES (?, ?, ?, ?, ?)'
  ).run(email, 'Fő Admin', 'SUPER_ADMIN', null, passwordHash);

  if (!process.env.SUPER_ADMIN_PASSWORD) {
    console.warn('[seed] SUPER_ADMIN_PASSWORD nincs beállítva. Ideiglenes jelszó:', password);
  }
}

module.exports = {
  initDb,
};
