const PERMISSIONS = [
  { key: 'ADMIN_DASHBOARD', label: 'Fő admin dashboard' },
  { key: 'TENANT_MANAGE', label: 'Halozatok kezelese' },
  { key: 'USER_MANAGE', label: 'Felhasznalok kezelese' },
  { key: 'ROLE_MANAGE', label: 'Szerepkorok kezelese' },
  { key: 'OAUTH_MANAGE', label: 'SSO beallitasok' },
  { key: 'AUDIT_VIEW_GLOBAL', label: 'Globalis audit' },
  { key: 'TENANT_DASHBOARD', label: 'Tenant dashboard' },
  { key: 'TENANT_USERS_MANAGE', label: 'Tenant userek kezelese' },
  { key: 'CUSTOMER_MANAGE', label: 'Ugyfelek kezelese' },
  { key: 'INTERACTION_CREATE', label: 'Interakciok rogzitese' },
  { key: 'AUDIT_VIEW_TENANT', label: 'Tenant audit' },
  { key: 'USER_DASHBOARD', label: 'User dashboard' },
];

const ACTION_PERMISSIONS = {
  TENANT_CREATE: ['TENANT_MANAGE'],
  USER_CREATE: ['USER_MANAGE', 'TENANT_USERS_MANAGE'],
  USER_SELF_REGISTER: [],
  USER_SSO_REGISTER: [],
  USER_ROLE_UPDATE: ['USER_MANAGE'],
  ROLE_UPDATE: ['ROLE_MANAGE'],
  OAUTH_SETTINGS_UPDATE: ['OAUTH_MANAGE'],
  CUSTOMER_CREATE: ['CUSTOMER_MANAGE'],
  CUSTOMER_UPDATE: ['CUSTOMER_MANAGE'],
  INTERACTION_CREATE: ['INTERACTION_CREATE'],
};

const DEFAULT_ROLES = [
  {
    name: 'SUPER_ADMIN',
    label: 'Fő Admin',
    permissions: PERMISSIONS.map((item) => item.key),
    isSystem: 1,
  },
  {
    name: 'TENANT_ADMIN',
    label: 'Tenant Admin',
    permissions: [
      'TENANT_DASHBOARD',
      'TENANT_USERS_MANAGE',
      'CUSTOMER_MANAGE',
      'INTERACTION_CREATE',
      'AUDIT_VIEW_TENANT',
    ],
    isSystem: 1,
  },
  {
    name: 'USER',
    label: 'User',
    permissions: ['USER_DASHBOARD', 'CUSTOMER_MANAGE', 'INTERACTION_CREATE'],
    isSystem: 1,
  },
];

module.exports = {
  PERMISSIONS,
  ACTION_PERMISSIONS,
  DEFAULT_ROLES,
};
