const countries = require('i18n-iso-countries');
const huLocale = require('i18n-iso-countries/langs/hu.json');
const { parsePhoneNumberFromString, getCountries, getCountryCallingCode } = require('libphonenumber-js/max');

countries.registerLocale(huLocale);

function validatePhone(countryCode, phone) {
  if (!countryCode) {
    return { ok: false, message: 'Orszag kotelezo.' };
  }

  const raw = (phone || '').trim();
  if (!raw) {
    return { ok: false, message: 'Telefon kotelezo.' };
  }

  const parsed = parsePhoneNumberFromString(raw, countryCode);
  if (!parsed || !parsed.isValid()) {
    return { ok: false, message: 'Hibas telefonszam az adott orszaghoz.' };
  }

  return {
    ok: true,
    e164: parsed.number,
    national: parsed.formatNational(),
  };
}

function getCountryOptions() {
  return getCountries()
    .map((code) => {
      const dial = `+${getCountryCallingCode(code)}`;
      const name = countries.getName(code, 'hu') || code;
      return {
        code,
        label: `${name} (${dial})`,
        dial,
      };
    })
    .sort((a, b) => a.label.localeCompare(b.label, 'hu'));
}

module.exports = {
  validatePhone,
  getCountryOptions,
};
