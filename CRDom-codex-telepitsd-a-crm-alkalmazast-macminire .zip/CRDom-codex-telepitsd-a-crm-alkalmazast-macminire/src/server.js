const path = require('path');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const { Issuer, generators } = require('openid-client');
const { SignJWT, importPKCS8 } = require('jose');
const { initDb } = require('./db');
const { recordAudit } = require('./audit');
const { hashPassword, verifyPassword } = require('./auth');
const { PERMISSIONS } = require('./permissions');
const { validatePhone, getCountryOptions } = require('./phone');

const app = express();
const db = initDb();

const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || 'dev-session-secret';
const BASE_URL = (process.env.BASE_URL || '').replace(/\/$/, '');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));
app.set('trust proxy', 1);

app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: false }));
app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
    },
  })
);

app.use((req, res, next) => {
  if (!req.session.userId) return next();
  const user = db
    .prepare('SELECT id, email, name, role, tenant_id FROM users WHERE id = ?')
    .get(req.session.userId);
  if (user) {
    req.user = user;
    res.locals.user = user;
    req.permissions = getRolePermissions(user.role);
    res.locals.permissions = req.permissions;
  }
  next();
});

app.use((req, res, next) => {
  if (!res.locals.user) {
    res.locals.user = null;
  }
  if (!res.locals.permissions) {
    res.locals.permissions = [];
  }
  res.locals.formatDateTime = (value) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString('hu-HU');
  };

  res.locals.toDateInput = (value) => {
    if (!value) return '';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return '';
    return date.toISOString().slice(0, 10);
  };

  next();
});

function requireAuth(req, res, next) {
  if (!req.user) return res.redirect('/login');
  return next();
}

function getRolePermissions(roleName) {
  if (!roleName) return [];
  if (roleName === 'SUPER_ADMIN') {
    return PERMISSIONS.map((item) => item.key);
  }
  const rows = db
    .prepare('SELECT permission_key FROM role_permissions WHERE role_name = ?')
    .all(roleName);
  return rows.map((row) => row.permission_key);
}

function hasPermission(req, permission) {
  if (!req.user) return false;
  if (req.user.role === 'SUPER_ADMIN') return true;
  return req.permissions && req.permissions.includes(permission);
}

function requirePermission(...permissions) {
  return (req, res, next) => {
    if (!req.user) return res.redirect('/login');
    if (permissions.length === 0) return next();
    const ok = permissions.some((permission) => hasPermission(req, permission));
    if (!ok) {
      return res.status(403).render('forbidden', { message: 'Nincs jogosultsag.' });
    }
    return next();
  };
}

function requireTenantContext(req, res, next) {
  if (!req.user || !req.user.tenant_id) {
    return res.status(403).render('forbidden', { message: 'Nincs hozzarendelt halozat.' });
  }
  return next();
}

function ensureTenantAccess(req, tenantId) {
  if (hasPermission(req, 'TENANT_MANAGE') || hasPermission(req, 'AUDIT_VIEW_GLOBAL')) return true;
  if (!req.user.tenant_id) return false;
  return Number(req.user.tenant_id) === Number(tenantId);
}

function getBaseUrl(req) {
  if (BASE_URL) return BASE_URL;
  const proto = (req.headers['x-forwarded-proto'] || req.protocol || 'http').split(',')[0];
  return `${proto}://${req.headers.host}`;
}

function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

const oauthCache = {
  google: null,
  apple: null,
};

async function getIssuer(provider) {
  if (oauthCache[provider]?.issuer) return oauthCache[provider].issuer;
  const discoveryUrl =
    provider === 'google' ? 'https://accounts.google.com' : 'https://appleid.apple.com';
  const issuer = await Issuer.discover(discoveryUrl);
  oauthCache[provider] = { issuer };
  return issuer;
}

async function createAppleClientSecret(settings) {
  const key = (settings.apple_private_key || '').trim().replace(/\\n/g, '\n');
  const now = Math.floor(Date.now() / 1000);
  const privateKey = await importPKCS8(key, 'ES256');
  return new SignJWT({})
    .setProtectedHeader({ alg: 'ES256', kid: settings.apple_key_id })
    .setIssuedAt(now)
    .setIssuer(settings.apple_team_id)
    .setAudience('https://appleid.apple.com')
    .setSubject(settings.apple_client_id)
    .setExpirationTime(now + 60 * 60 * 24)
    .sign(privateKey);
}

async function getOAuthClient(provider, req) {
  const settings = getSettings([
    'google_client_id',
    'google_client_secret',
    'apple_client_id',
    'apple_team_id',
    'apple_key_id',
    'apple_private_key',
  ]);

  const baseUrl = getBaseUrl(req);
  const redirectUri = `${baseUrl}/auth/${provider}/callback`;

  if (provider === 'google') {
    if (!settings.google_client_id || !settings.google_client_secret) {
      return { client: null, settings, redirectUri };
    }
    const issuer = await getIssuer('google');
    const client = new issuer.Client({
      client_id: settings.google_client_id,
      client_secret: settings.google_client_secret,
      redirect_uris: [redirectUri],
      response_types: ['code'],
    });
    return { client, settings, redirectUri };
  }

  if (provider === 'apple') {
    if (
      !settings.apple_client_id ||
      !settings.apple_team_id ||
      !settings.apple_key_id ||
      !settings.apple_private_key
    ) {
      return { client: null, settings, redirectUri };
    }
    const issuer = await getIssuer('apple');
    const clientSecret = await createAppleClientSecret(settings);
    const client = new issuer.Client({
      client_id: settings.apple_client_id,
      client_secret: clientSecret,
      redirect_uris: [redirectUri],
      response_types: ['code'],
    });
    return { client, settings, redirectUri };
  }

  return { client: null, settings: {}, redirectUri };
}

function getRoles() {
  return db.prepare('SELECT name, label, is_system FROM roles ORDER BY name ASC').all();
}

function getPermissions() {
  return db.prepare('SELECT key, label FROM permissions ORDER BY label ASC').all();
}

function getSettings(keys) {
  if (!keys.length) return {};
  const rows = db
    .prepare(`SELECT key, value FROM settings WHERE key IN (${keys.map(() => '?').join(',')})`)
    .all(...keys);
  return rows.reduce((acc, row) => {
    acc[row.key] = row.value;
    return acc;
  }, {});
}

function setSetting(key, value) {
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(
    key,
    value
  );
}

function normalizeRoleName(raw) {
  return (raw || '')
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9_]/g, '_')
    .replace(/_{2,}/g, '_');
}

function toCsv(rows, columns) {
  const escape = (value) => {
    if (value === null || value === undefined) return '';
    const str = String(value);
    if (str.includes('"') || str.includes(',') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const header = columns.map((col) => col.label).join(',');
  const lines = rows.map((row) => columns.map((col) => escape(row[col.key])).join(','));
  return [header, ...lines].join('\n');
}

app.get('/', (req, res) => {
  if (!req.user) return res.redirect('/login');
  return res.redirect('/dashboard');
});

app.get('/login', (req, res) => {
  if (req.user) return res.redirect('/dashboard');
  const notice = req.query.registered ? 'Sikeres regisztracio. Jelentkezz be.' : null;
  return res.render('login', { error: null, notice });
});

app.get('/register', (req, res) => {
  if (req.user) return res.redirect('/dashboard');
  const tenants = db.prepare('SELECT id, name FROM tenants ORDER BY name ASC').all();
  const countries = getCountryOptions();
  const error = tenants.length === 0 ? 'Nincs elerheto halozat. Keresd a foadmint.' : null;
  return res.render('register', {
    error,
    tenants,
    countries,
    form: {},
  });
});

app.post('/register', (req, res) => {
  if (req.user) return res.redirect('/dashboard');
  const tenants = db.prepare('SELECT id, name FROM tenants ORDER BY name ASC').all();
  const countries = getCountryOptions();
  if (tenants.length === 0) {
    return res.render('register', {
      error: 'Nincs elerheto halozat. Keresd a foadmint.',
      tenants,
      countries,
      form: {},
    });
  }

  const name = (req.body.name || '').trim();
  const email = (req.body.email || '').trim().toLowerCase();
  const password = req.body.password;
  const tenantId = req.body.tenant_id ? Number(req.body.tenant_id) : null;
  const phoneCountry = req.body.phone_country || '';
  const phoneNumber = req.body.phone_number || '';

  if (!name || !email || !password || !tenantId || !phoneCountry) {
    return res.render('register', {
      error: 'Minden mezot ki kell tolteni.',
      tenants,
      countries,
      form: { name, email, tenant_id: tenantId, phone_country: phoneCountry, phone_number: phoneNumber },
    });
  }

  const phoneCheck = validatePhone(phoneCountry, phoneNumber);
  if (!phoneCheck.ok) {
    return res.render('register', {
      error: phoneCheck.message,
      tenants,
      countries,
      form: { name, email, tenant_id: tenantId, phone_country: phoneCountry, phone_number: phoneNumber },
    });
  }

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    return res.render('register', {
      error: 'Ezzel az emaillel mar letezik felhasznalo.',
      tenants,
      countries,
      form: { name, email, tenant_id: tenantId, phone_country: phoneCountry, phone_number: phoneNumber },
    });
  }

  const passwordHash = hashPassword(password);
  const info = db
    .prepare(
      'INSERT INTO users (email, name, role, tenant_id, password_hash, phone_country, phone_number) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
    .run(email, name, 'USER', tenantId, passwordHash, phoneCountry, phoneCheck.e164);

  recordAudit(db, {
    tenantId,
    entityType: 'USER',
    entityId: info.lastInsertRowid,
    action: 'USER_SELF_REGISTER',
    actorUserId: null,
    actorRole: 'PUBLIC',
    data: { email, role: 'USER', tenantId },
  });

  return res.redirect('/login?registered=1');
});

app.get('/sso/complete', (req, res) => {
  if (req.user) return res.redirect('/dashboard');
  const profile = req.session.ssoProfile;
  if (!profile) {
    return res.redirect('/login');
  }
  const tenants = db.prepare('SELECT id, name FROM tenants ORDER BY name ASC').all();
  const countries = getCountryOptions();
  const error = tenants.length === 0 ? 'Nincs elerheto halozat. Keresd a foadmint.' : null;
  return res.render('sso_complete', {
    error,
    tenants,
    countries,
    profile,
    form: {},
  });
});

app.post('/sso/complete', (req, res) => {
  if (req.user) return res.redirect('/dashboard');
  const profile = req.session.ssoProfile;
  if (!profile) {
    return res.redirect('/login');
  }

  const tenants = db.prepare('SELECT id, name FROM tenants ORDER BY name ASC').all();
  const countries = getCountryOptions();
  if (tenants.length === 0) {
    return res.render('sso_complete', {
      error: 'Nincs elerheto halozat. Keresd a foadmint.',
      tenants,
      countries,
      profile,
      form: {},
    });
  }

  const name = (req.body.name || profile.name || '').trim();
  const tenantId = req.body.tenant_id ? Number(req.body.tenant_id) : null;
  const phoneCountry = req.body.phone_country || '';
  const phoneNumber = req.body.phone_number || '';

  if (!name || !tenantId || !phoneCountry) {
    return res.render('sso_complete', {
      error: 'Minden mezot ki kell tolteni.',
      tenants,
      countries,
      profile,
      form: { name, tenant_id: tenantId, phone_country: phoneCountry, phone_number: phoneNumber },
    });
  }

  const phoneCheck = validatePhone(phoneCountry, phoneNumber);
  if (!phoneCheck.ok) {
    return res.render('sso_complete', {
      error: phoneCheck.message,
      tenants,
      countries,
      profile,
      form: { name, tenant_id: tenantId, phone_country: phoneCountry, phone_number: phoneNumber },
    });
  }

  const existing = db.prepare('SELECT id, is_active FROM users WHERE email = ?').get(profile.email);
  if (existing) {
    if (!existing.is_active) {
      return res.render('sso_complete', {
        error: 'A fiok inaktiv. Lepj kapcsolatba a foadminnal.',
        tenants,
        countries,
        profile,
        form: { name, tenant_id: tenantId, phone_country: phoneCountry, phone_number: phoneNumber },
      });
    }
    req.session.userId = existing.id;
    return res.redirect('/dashboard');
  }

  const passwordHash = hashPassword(crypto.randomBytes(12).toString('hex'));
  const info = db
    .prepare(
      'INSERT INTO users (email, name, role, tenant_id, password_hash, phone_country, phone_number) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
    .run(profile.email, name, 'USER', tenantId, passwordHash, phoneCountry, phoneCheck.e164);

  db.prepare(
    'INSERT OR IGNORE INTO oauth_accounts (provider, subject, user_id, email) VALUES (?, ?, ?, ?)'
  ).run(profile.provider, profile.subject, info.lastInsertRowid, profile.email);

  recordAudit(db, {
    tenantId,
    entityType: 'USER',
    entityId: info.lastInsertRowid,
    action: 'USER_SSO_REGISTER',
    actorUserId: null,
    actorRole: 'PUBLIC',
    data: { email: profile.email, role: 'USER', tenantId },
  });

  req.session.ssoProfile = null;
  req.session.userId = info.lastInsertRowid;
  return res.redirect('/dashboard');
});

app.get(
  '/auth/:provider',
  asyncHandler(async (req, res) => {
    const provider = req.params.provider;
    const allowed = ['google', 'apple'];
    if (!allowed.includes(provider)) {
      return res.status(404).render('forbidden', { message: 'Ismeretlen belepesi mod.' });
    }

    const { client, redirectUri } = await getOAuthClient(provider, req);
    if (!client) {
      return res.render('oauth_status', {
        provider,
        ready: false,
        baseUrl: getBaseUrl(req),
      });
    }

    const codeVerifier = generators.codeVerifier();
    const codeChallenge = generators.codeChallenge(codeVerifier);
    const state = generators.state();
    const nonce = generators.nonce();

    req.session.oauth = {
      provider,
      code_verifier: codeVerifier,
      state,
      nonce,
      redirect_uri: redirectUri,
    };

    const scope = provider === 'apple' ? 'openid email name' : 'openid email profile';

    const authorizationUrl = client.authorizationUrl({
      scope,
      state,
      nonce,
      code_challenge: codeChallenge,
      code_challenge_method: 'S256',
      response_mode: provider === 'apple' ? 'form_post' : undefined,
    });

    return res.redirect(authorizationUrl);
  })
);

app.all(
  '/auth/:provider/callback',
  asyncHandler(async (req, res) => {
    const provider = req.params.provider;
    const allowed = ['google', 'apple'];
    if (!allowed.includes(provider)) {
      return res.status(404).render('forbidden', { message: 'Ismeretlen belepesi mod.' });
    }

    const oauthSession = req.session.oauth;
    if (!oauthSession || oauthSession.provider !== provider) {
      return res.render('oauth_status', {
        provider,
        ready: false,
        baseUrl: getBaseUrl(req),
      });
    }

    const { client, redirectUri } = await getOAuthClient(provider, req);
    if (!client) {
      return res.render('oauth_status', {
        provider,
        ready: false,
        baseUrl: getBaseUrl(req),
      });
    }

    const params = client.callbackParams(req);
    const tokenSet = await client.callback(
      oauthSession.redirect_uri || redirectUri,
      params,
      {
        state: oauthSession.state,
        nonce: oauthSession.nonce,
        code_verifier: oauthSession.code_verifier,
      }
    );

    const claims = tokenSet.claims();
    let email = claims.email;
    let subject = claims.sub;
    let name = claims.name || '';

    if (provider === 'apple' && req.body && req.body.user) {
      try {
        const appleUser = JSON.parse(req.body.user);
        const fullName = [appleUser?.name?.firstName, appleUser?.name?.lastName]
          .filter(Boolean)
          .join(' ');
        if (fullName) name = fullName;
      } catch (err) {
        // ignore malformed payload
      }
    }

    req.session.oauth = null;

    if (!email || !subject) {
      return res.render('oauth_status', {
        provider,
        ready: false,
        baseUrl: getBaseUrl(req),
        message: 'Az OAuth nem adott vissza email cimet.',
      });
    }

    const existingAccount = db
      .prepare('SELECT user_id FROM oauth_accounts WHERE provider = ? AND subject = ?')
      .get(provider, subject);
    let user = null;
    if (existingAccount) {
      user = db
        .prepare('SELECT id, is_active FROM users WHERE id = ?')
        .get(existingAccount.user_id);
    } else {
      user = db.prepare('SELECT id, is_active FROM users WHERE email = ?').get(email.toLowerCase());
      if (user) {
        db.prepare(
          'INSERT OR IGNORE INTO oauth_accounts (provider, subject, user_id, email) VALUES (?, ?, ?, ?)'
        ).run(provider, subject, user.id, email.toLowerCase());
      }
    }

    if (user && user.is_active) {
      req.session.userId = user.id;
      return res.redirect('/dashboard');
    }

    req.session.ssoProfile = {
      provider,
      subject,
      email: email.toLowerCase(),
      name,
    };
    return res.redirect('/sso/complete');
  })
);

app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = db
    .prepare('SELECT id, email, name, role, tenant_id, password_hash, is_active FROM users WHERE email = ?')
    .get(email);

  if (!user || !user.is_active) {
    return res.render('login', { error: 'Hibas belepes.', notice: null });
  }

  const ok = verifyPassword(password, user.password_hash);
  if (!ok) {
    return res.render('login', { error: 'Hibas belepes.', notice: null });
  }

  req.session.userId = user.id;
  return res.redirect('/dashboard');
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

app.get('/dashboard', requireAuth, (req, res) => {
  if (hasPermission(req, 'ADMIN_DASHBOARD')) return res.redirect('/admin/overview');
  if (hasPermission(req, 'TENANT_DASHBOARD')) return res.redirect('/tenant/overview');
  return res.redirect('/app/overview');
});

// SUPER ADMIN ROUTES
app.get('/admin/overview', requirePermission('ADMIN_DASHBOARD'), (req, res) => {
  const tenantCount = db.prepare('SELECT COUNT(*) AS count FROM tenants').get().count;
  const userCount = db.prepare('SELECT COUNT(*) AS count FROM users').get().count;
  const customerCount = db.prepare('SELECT COUNT(*) AS count FROM customers').get().count;
  const recentAudit = db
    .prepare(
      `SELECT ae.*, u.email AS actor_email, t.name AS tenant_name
       FROM audit_events ae
       LEFT JOIN users u ON u.id = ae.actor_user_id
       LEFT JOIN tenants t ON t.id = ae.tenant_id
       ORDER BY ae.created_at DESC
       LIMIT 12`
    )
    .all();

  res.render('admin/overview', {
    tenantCount,
    userCount,
    customerCount,
    recentAudit,
  });
});

app.get('/admin/tenants', requirePermission('TENANT_MANAGE'), (req, res) => {
  const tenants = db.prepare('SELECT * FROM tenants ORDER BY created_at DESC').all();
  res.render('admin/tenants', { tenants, error: null });
});

app.post('/admin/tenants', requirePermission('TENANT_MANAGE'), (req, res) => {
  const name = (req.body.name || '').trim();
  if (!name) {
    const tenants = db.prepare('SELECT * FROM tenants ORDER BY created_at DESC').all();
    return res.render('admin/tenants', { tenants, error: 'A nev kotelezo.' });
  }

  const info = db.prepare('INSERT INTO tenants (name) VALUES (?)').run(name);
  recordAudit(db, {
    tenantId: info.lastInsertRowid,
    entityType: 'TENANT',
    entityId: info.lastInsertRowid,
    action: 'TENANT_CREATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    data: { name },
  });

  return res.redirect('/admin/tenants');
});

app.get('/admin/users', requirePermission('USER_MANAGE'), (req, res) => {
  const users = db
    .prepare(
      `SELECT u.*, t.name AS tenant_name
       FROM users u
       LEFT JOIN tenants t ON t.id = u.tenant_id
       ORDER BY u.created_at DESC`
    )
    .all();
  const tenants = db.prepare('SELECT * FROM tenants ORDER BY name ASC').all();
  const roles = getRoles();
  const countries = getCountryOptions();
  res.render('admin/users', { users, tenants, roles, countries, error: null });
});

app.post('/admin/users', requirePermission('USER_MANAGE'), (req, res) => {
  const email = (req.body.email || '').trim().toLowerCase();
  const name = (req.body.name || '').trim();
  const role = req.body.role;
  const tenantId = req.body.tenant_id ? Number(req.body.tenant_id) : null;
  const password = req.body.password;
  const phoneCountry = req.body.phone_country || '';
  const phoneNumber = req.body.phone_number || '';

  const tenants = db.prepare('SELECT * FROM tenants ORDER BY name ASC').all();
  const roles = getRoles();

  if (!email || !name || !role || !password) {
    const users = db
      .prepare(
        `SELECT u.*, t.name AS tenant_name
         FROM users u
         LEFT JOIN tenants t ON t.id = u.tenant_id
         ORDER BY u.created_at DESC`
      )
      .all();
    return res.render('admin/users', { users, tenants, roles, countries: getCountryOptions(), error: 'Minden mezot ki kell tolteni.' });
  }

  const roleExists = roles.some((item) => item.name === role);
  if (!roleExists) {
    const users = db
      .prepare(
        `SELECT u.*, t.name AS tenant_name
         FROM users u
         LEFT JOIN tenants t ON t.id = u.tenant_id
         ORDER BY u.created_at DESC`
      )
      .all();
    return res.render('admin/users', { users, tenants, roles, countries: getCountryOptions(), error: 'Ismeretlen szerep.' });
  }

  const rolePermissions = getRolePermissions(role);
  const isGlobalRole = role === 'SUPER_ADMIN' || rolePermissions.some((p) => ['TENANT_MANAGE', 'AUDIT_VIEW_GLOBAL', 'ADMIN_DASHBOARD'].includes(p));
  if (!isGlobalRole && !tenantId) {
    const users = db
      .prepare(
        `SELECT u.*, t.name AS tenant_name
         FROM users u
         LEFT JOIN tenants t ON t.id = u.tenant_id
         ORDER BY u.created_at DESC`
      )
      .all();
    return res.render('admin/users', { users, tenants, roles, countries: getCountryOptions(), error: 'Tenant kotelezo ehhez a szerephez.' });
  }

  let normalizedPhone = null;
  if (phoneNumber) {
    const phoneCheck = validatePhone(phoneCountry, phoneNumber);
    if (!phoneCheck.ok) {
      const users = db
        .prepare(
          `SELECT u.*, t.name AS tenant_name
           FROM users u
           LEFT JOIN tenants t ON t.id = u.tenant_id
           ORDER BY u.created_at DESC`
        )
        .all();
      return res.render('admin/users', { users, tenants, roles, countries: getCountryOptions(), error: phoneCheck.message });
    }
    normalizedPhone = phoneCheck.e164;
  }

  const passwordHash = hashPassword(password);
  const info = db
    .prepare(
      'INSERT INTO users (email, name, role, tenant_id, password_hash, phone_country, phone_number) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
    .run(email, name, role, tenantId, passwordHash, phoneCountry || null, normalizedPhone);

  recordAudit(db, {
    tenantId,
    entityType: 'USER',
    entityId: info.lastInsertRowid,
    action: 'USER_CREATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    data: { email, role, tenantId },
  });

  return res.redirect('/admin/users');
});

app.post('/admin/users/:id/role', requirePermission('USER_MANAGE'), (req, res) => {
  const userId = Number(req.params.id);
  const role = req.body.role;
  const tenantId = req.body.tenant_id ? Number(req.body.tenant_id) : null;

  const roles = getRoles();
  const roleExists = roles.some((item) => item.name === role);
  if (!roleExists) {
    return res.status(400).render('forbidden', { message: 'Ismeretlen szerep.' });
  }

  const rolePermissions = getRolePermissions(role);
  const isGlobalRole = role === 'SUPER_ADMIN' || rolePermissions.some((p) => ['TENANT_MANAGE', 'AUDIT_VIEW_GLOBAL', 'ADMIN_DASHBOARD'].includes(p));
  if (!isGlobalRole && !tenantId) {
    return res.status(400).render('forbidden', { message: 'Tenant kotelezo ehhez a szerephez.' });
  }

  db.prepare('UPDATE users SET role = ?, tenant_id = ? WHERE id = ?').run(role, tenantId, userId);

  recordAudit(db, {
    tenantId,
    entityType: 'USER',
    entityId: userId,
    action: 'USER_ROLE_UPDATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    data: { role, tenantId },
  });

  return res.redirect('/admin/users');
});

app.get('/admin/audit', requirePermission('AUDIT_VIEW_GLOBAL'), (req, res) => {
  const events = db
    .prepare(
      `SELECT ae.*, u.email AS actor_email, t.name AS tenant_name
       FROM audit_events ae
       LEFT JOIN users u ON u.id = ae.actor_user_id
       LEFT JOIN tenants t ON t.id = ae.tenant_id
       ORDER BY ae.created_at DESC
       LIMIT 100`
    )
    .all();
  const findings = db
    .prepare(
      `SELECT af.*, t.name AS tenant_name
       FROM audit_findings af
       JOIN audit_events ae ON ae.id = af.audit_event_id
       LEFT JOIN tenants t ON t.id = ae.tenant_id
       ORDER BY af.created_at DESC
       LIMIT 200`
    )
    .all();
  res.render('admin/audit', { events, findings });
});

app.get('/admin/audit/export', requirePermission('AUDIT_VIEW_GLOBAL'), (req, res) => {
  const format = (req.query.format || 'csv').toLowerCase();
  const kind = (req.query.kind || 'events').toLowerCase();

  if (kind === 'findings') {
    const rows = db
      .prepare(
        `SELECT af.*, t.name AS tenant_name
         FROM audit_findings af
         JOIN audit_events ae ON ae.id = af.audit_event_id
         LEFT JOIN tenants t ON t.id = ae.tenant_id
         ORDER BY af.created_at DESC`
      )
      .all();
    if (format === 'json') {
      res.setHeader('Content-Type', 'application/json');
      return res.send(JSON.stringify(rows, null, 2));
    }
    const csv = toCsv(rows, [
      { key: 'id', label: 'id' },
      { key: 'created_at', label: 'created_at' },
      { key: 'tenant_name', label: 'tenant' },
      { key: 'agent', label: 'agent' },
      { key: 'tier', label: 'tier' },
      { key: 'status', label: 'status' },
      { key: 'severity', label: 'severity' },
      { key: 'summary', label: 'summary' },
    ]);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="audit-findings.csv"');
    return res.send(csv);
  }

  const rows = db
    .prepare(
      `SELECT ae.*, u.email AS actor_email, t.name AS tenant_name
       FROM audit_events ae
       LEFT JOIN users u ON u.id = ae.actor_user_id
       LEFT JOIN tenants t ON t.id = ae.tenant_id
       ORDER BY ae.created_at DESC`
    )
    .all();
  if (format === 'json') {
    res.setHeader('Content-Type', 'application/json');
    return res.send(JSON.stringify(rows, null, 2));
  }
  const csv = toCsv(rows, [
    { key: 'id', label: 'id' },
    { key: 'created_at', label: 'created_at' },
    { key: 'tenant_name', label: 'tenant' },
    { key: 'action', label: 'action' },
    { key: 'entity_type', label: 'entity_type' },
    { key: 'entity_id', label: 'entity_id' },
    { key: 'actor_email', label: 'actor_email' },
    { key: 'actor_role', label: 'actor_role' },
  ]);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="audit-events.csv"');
  return res.send(csv);
});

app.get('/admin/roles', requirePermission('ROLE_MANAGE'), (req, res) => {
  const roles = getRoles();
  const allPermissions = getPermissions();
  const rolePermRows = db.prepare('SELECT role_name, permission_key FROM role_permissions').all();
  const rolePermissions = rolePermRows.reduce((acc, row) => {
    if (!acc[row.role_name]) acc[row.role_name] = [];
    acc[row.role_name].push(row.permission_key);
    return acc;
  }, {});

  res.render('admin/roles', {
    roles,
    allPermissions,
    rolePermissions,
    error: null,
  });
});

app.post('/admin/roles', requirePermission('ROLE_MANAGE'), (req, res) => {
  const name = normalizeRoleName(req.body.name);
  const label = (req.body.label || '').trim();
  const permissions = Array.isArray(req.body.permissions) ? req.body.permissions : [req.body.permissions].filter(Boolean);

  if (!name || !label) {
    const roles = getRoles();
    const permissionsList = getPermissions();
    const rolePermRows = db.prepare('SELECT role_name, permission_key FROM role_permissions').all();
    const rolePermissions = rolePermRows.reduce((acc, row) => {
      if (!acc[row.role_name]) acc[row.role_name] = [];
      acc[row.role_name].push(row.permission_key);
      return acc;
    }, {});
    return res.render('admin/roles', {
      roles,
      allPermissions: permissionsList,
      rolePermissions,
      error: 'Nev es label kotelezo.',
    });
  }

  db.prepare('INSERT OR IGNORE INTO roles (name, label, is_system) VALUES (?, ?, 0)').run(name, label);
  db.prepare('DELETE FROM role_permissions WHERE role_name = ?').run(name);
  const insertRolePermission = db.prepare(
    'INSERT OR IGNORE INTO role_permissions (role_name, permission_key) VALUES (?, ?)'
  );
  for (const permission of permissions) {
    insertRolePermission.run(name, permission);
  }

  recordAudit(db, {
    tenantId: null,
    entityType: 'ROLE',
    entityId: 0,
    action: 'ROLE_UPDATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    data: { role: name, permissions },
  });

  return res.redirect('/admin/roles');
});

app.post('/admin/roles/:name/permissions', requirePermission('ROLE_MANAGE'), (req, res) => {
  const name = req.params.name;
  const permissions = Array.isArray(req.body.permissions) ? req.body.permissions : [req.body.permissions].filter(Boolean);

  db.prepare('DELETE FROM role_permissions WHERE role_name = ?').run(name);
  const insertRolePermission = db.prepare(
    'INSERT OR IGNORE INTO role_permissions (role_name, permission_key) VALUES (?, ?)'
  );
  for (const permission of permissions) {
    insertRolePermission.run(name, permission);
  }

  recordAudit(db, {
    tenantId: null,
    entityType: 'ROLE',
    entityId: 0,
    action: 'ROLE_UPDATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    data: { role: name, permissions },
  });

  return res.redirect('/admin/roles');
});

app.get('/admin/oauth', requirePermission('OAUTH_MANAGE'), (req, res) => {
  const settings = getSettings([
    'google_client_id',
    'google_client_secret',
    'apple_client_id',
    'apple_team_id',
    'apple_key_id',
    'apple_private_key',
  ]);
  res.render('admin/oauth', { settings, error: null, baseUrl: getBaseUrl(req) });
});

app.post('/admin/oauth', requirePermission('OAUTH_MANAGE'), (req, res) => {
  const keys = [
    'google_client_id',
    'google_client_secret',
    'apple_client_id',
    'apple_team_id',
    'apple_key_id',
    'apple_private_key',
  ];

  for (const key of keys) {
    const value = (req.body[key] || '').trim();
    setSetting(key, value);
  }

  recordAudit(db, {
    tenantId: null,
    entityType: 'OAUTH_SETTINGS',
    entityId: 0,
    action: 'OAUTH_SETTINGS_UPDATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    data: { keys: keys.filter((key) => (req.body[key] || '').trim()).length },
  });

  return res.redirect('/admin/oauth');
});

// TENANT ADMIN ROUTES
app.get('/tenant/overview', requirePermission('TENANT_DASHBOARD'), requireTenantContext, (req, res) => {
  const tenantId = req.user.tenant_id;
  const userCount = db
    .prepare('SELECT COUNT(*) AS count FROM users WHERE tenant_id = ? AND role = ?')
    .get(tenantId, 'USER').count;
  const customerCount = db
    .prepare('SELECT COUNT(*) AS count FROM customers WHERE tenant_id = ?')
    .get(tenantId).count;
  const upcoming = db
    .prepare(
      `SELECT * FROM customers
       WHERE tenant_id = ?
       ORDER BY next_followup_at ASC
       LIMIT 10`
    )
    .all(tenantId);

  res.render('tenant/overview', { userCount, customerCount, upcoming });
});

app.get('/tenant/users', requirePermission('TENANT_USERS_MANAGE'), requireTenantContext, (req, res) => {
  const tenantId = req.user.tenant_id;
  const users = db
    .prepare('SELECT * FROM users WHERE tenant_id = ? ORDER BY created_at DESC')
    .all(tenantId);
  res.render('tenant/users', { users, error: null, countries: getCountryOptions() });
});

app.post('/tenant/users', requirePermission('TENANT_USERS_MANAGE'), requireTenantContext, (req, res) => {
  const tenantId = req.user.tenant_id;
  const email = (req.body.email || '').trim().toLowerCase();
  const name = (req.body.name || '').trim();
  const password = req.body.password;
  const phoneCountry = req.body.phone_country || '';
  const phoneNumber = req.body.phone_number || '';

  const users = db
    .prepare('SELECT * FROM users WHERE tenant_id = ? ORDER BY created_at DESC')
    .all(tenantId);

  if (!email || !name || !password) {
    return res.render('tenant/users', { users, error: 'Minden mezot ki kell tolteni.', countries: getCountryOptions() });
  }

  let normalizedPhone = null;
  if (phoneNumber) {
    const phoneCheck = validatePhone(phoneCountry, phoneNumber);
    if (!phoneCheck.ok) {
      return res.render('tenant/users', { users, error: phoneCheck.message, countries: getCountryOptions() });
    }
    normalizedPhone = phoneCheck.e164;
  }

  const passwordHash = hashPassword(password);
  const info = db
    .prepare(
      'INSERT INTO users (email, name, role, tenant_id, password_hash, phone_country, phone_number) VALUES (?, ?, ?, ?, ?, ?, ?)'
    )
    .run(email, name, 'USER', tenantId, passwordHash, phoneCountry || null, normalizedPhone);

  recordAudit(db, {
    tenantId,
    entityType: 'USER',
    entityId: info.lastInsertRowid,
    action: 'USER_CREATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    data: { email, role: 'USER', tenantId },
  });

  return res.redirect('/tenant/users');
});

app.get('/tenant/customers', requirePermission('CUSTOMER_MANAGE'), requireTenantContext, (req, res) => {
  const tenantId = req.user.tenant_id;
  const customers = db
    .prepare(
      `SELECT c.*, u.name AS owner_name
       FROM customers c
       LEFT JOIN users u ON u.id = c.owner_user_id
       WHERE c.tenant_id = ?
       ORDER BY c.updated_at DESC`
    )
    .all(tenantId);
  const users = db
    .prepare('SELECT id, name FROM users WHERE tenant_id = ? ORDER BY name ASC')
    .all(tenantId);
  res.render('tenant/customers', { customers, users, error: null });
});

app.post('/tenant/customers', requirePermission('CUSTOMER_MANAGE'), requireTenantContext, (req, res) => {
  const tenantId = req.user.tenant_id;
  const name = (req.body.name || '').trim();
  const email = (req.body.email || '').trim();
  const phone = (req.body.phone || '').trim();
  const status = req.body.status || 'new';
  const nextFollowup = req.body.next_followup_at || null;
  const notes = (req.body.notes || '').trim();
  const ownerUserId = req.body.owner_user_id ? Number(req.body.owner_user_id) : null;

  const users = db
    .prepare('SELECT id, name FROM users WHERE tenant_id = ? ORDER BY name ASC')
    .all(tenantId);

  if (!name) {
    const customers = db
      .prepare(
        `SELECT c.*, u.name AS owner_name
         FROM customers c
         LEFT JOIN users u ON u.id = c.owner_user_id
         WHERE c.tenant_id = ?
         ORDER BY c.updated_at DESC`
      )
      .all(tenantId);
    return res.render('tenant/customers', { customers, users, error: 'Nev kotelezo.' });
  }

  const info = db
    .prepare(
      `INSERT INTO customers (tenant_id, owner_user_id, name, email, phone, status, next_followup_at, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(tenantId, ownerUserId, name, email, phone, status, nextFollowup, notes);

  recordAudit(db, {
    tenantId,
    entityType: 'CUSTOMER',
    entityId: info.lastInsertRowid,
    action: 'CUSTOMER_CREATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    after: { name, email, phone, status, next_followup_at: nextFollowup, notes },
  });

  return res.redirect('/tenant/customers');
});

app.get('/tenant/audit', requirePermission('AUDIT_VIEW_TENANT'), requireTenantContext, (req, res) => {
  const tenantId = req.user.tenant_id;
  const events = db
    .prepare(
      `SELECT ae.*, u.email AS actor_email
       FROM audit_events ae
       LEFT JOIN users u ON u.id = ae.actor_user_id
       WHERE ae.tenant_id = ?
       ORDER BY ae.created_at DESC
       LIMIT 50`
    )
    .all(tenantId);
  const findings = db
    .prepare(
      `SELECT af.* FROM audit_findings af
       JOIN audit_events ae ON ae.id = af.audit_event_id
       WHERE ae.tenant_id = ?
       ORDER BY af.created_at DESC`
    )
    .all(tenantId);
  res.render('tenant/audit', { events, findings });
});

app.get('/tenant/audit/export', requirePermission('AUDIT_VIEW_TENANT'), requireTenantContext, (req, res) => {
  const tenantId = req.user.tenant_id;
  const format = (req.query.format || 'csv').toLowerCase();
  const kind = (req.query.kind || 'events').toLowerCase();

  if (kind === 'findings') {
    const rows = db
      .prepare(
        `SELECT af.*
         FROM audit_findings af
         JOIN audit_events ae ON ae.id = af.audit_event_id
         WHERE ae.tenant_id = ?
         ORDER BY af.created_at DESC`
      )
      .all(tenantId);
    if (format === 'json') {
      res.setHeader('Content-Type', 'application/json');
      return res.send(JSON.stringify(rows, null, 2));
    }
    const csv = toCsv(rows, [
      { key: 'id', label: 'id' },
      { key: 'created_at', label: 'created_at' },
      { key: 'agent', label: 'agent' },
      { key: 'tier', label: 'tier' },
      { key: 'status', label: 'status' },
      { key: 'severity', label: 'severity' },
      { key: 'summary', label: 'summary' },
    ]);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="tenant-audit-findings.csv"');
    return res.send(csv);
  }

  const rows = db
    .prepare(
      `SELECT ae.*, u.email AS actor_email
       FROM audit_events ae
       LEFT JOIN users u ON u.id = ae.actor_user_id
       WHERE ae.tenant_id = ?
       ORDER BY ae.created_at DESC`
    )
    .all(tenantId);
  if (format === 'json') {
    res.setHeader('Content-Type', 'application/json');
    return res.send(JSON.stringify(rows, null, 2));
  }
  const csv = toCsv(rows, [
    { key: 'id', label: 'id' },
    { key: 'created_at', label: 'created_at' },
    { key: 'action', label: 'action' },
    { key: 'entity_type', label: 'entity_type' },
    { key: 'entity_id', label: 'entity_id' },
    { key: 'actor_email', label: 'actor_email' },
    { key: 'actor_role', label: 'actor_role' },
  ]);
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="tenant-audit-events.csv"');
  return res.send(csv);
});

// USER ROUTES
app.get('/app/overview', requirePermission('USER_DASHBOARD'), requireTenantContext, (req, res) => {
  const userId = req.user.id;
  const upcoming = db
    .prepare(
      `SELECT * FROM customers
       WHERE owner_user_id = ?
       ORDER BY next_followup_at ASC
       LIMIT 10`
    )
    .all(userId);
  const customerCount = db
    .prepare('SELECT COUNT(*) AS count FROM customers WHERE owner_user_id = ?')
    .get(userId).count;
  res.render('user/overview', { upcoming, customerCount });
});

app.get('/app/customers', requirePermission('CUSTOMER_MANAGE'), requireTenantContext, (req, res) => {
  const userId = req.user.id;
  const customers = db
    .prepare('SELECT * FROM customers WHERE owner_user_id = ? ORDER BY updated_at DESC')
    .all(userId);
  res.render('user/customers', { customers, error: null });
});

app.post('/app/customers', requirePermission('CUSTOMER_MANAGE'), requireTenantContext, (req, res) => {
  const name = (req.body.name || '').trim();
  const email = (req.body.email || '').trim();
  const phone = (req.body.phone || '').trim();
  const status = req.body.status || 'new';
  const nextFollowup = req.body.next_followup_at || null;
  const notes = (req.body.notes || '').trim();

  const customers = db
    .prepare('SELECT * FROM customers WHERE owner_user_id = ? ORDER BY updated_at DESC')
    .all(req.user.id);

  if (!name) {
    return res.render('user/customers', { customers, error: 'Nev kotelezo.' });
  }

  const info = db
    .prepare(
      `INSERT INTO customers (tenant_id, owner_user_id, name, email, phone, status, next_followup_at, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(req.user.tenant_id, req.user.id, name, email, phone, status, nextFollowup, notes);

  recordAudit(db, {
    tenantId: req.user.tenant_id,
    entityType: 'CUSTOMER',
    entityId: info.lastInsertRowid,
    action: 'CUSTOMER_CREATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    after: { name, email, phone, status, next_followup_at: nextFollowup, notes },
  });

  return res.redirect('/app/customers');
});

app.get('/app/customers/:id', requirePermission('CUSTOMER_MANAGE'), requireTenantContext, (req, res) => {
  const customerId = Number(req.params.id);
  const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(customerId);
  if (!customer || customer.owner_user_id !== req.user.id) {
    return res.status(404).render('forbidden', { message: 'Nem talalhato ugyfel.' });
  }
  const interactions = db
    .prepare(
      `SELECT i.*, u.name AS user_name
       FROM interactions i
       LEFT JOIN users u ON u.id = i.user_id
       WHERE i.customer_id = ?
       ORDER BY i.created_at DESC`
    )
    .all(customerId);
  res.render('user/customer_detail', { customer, interactions, error: null });
});

app.post('/app/customers/:id/update', requirePermission('CUSTOMER_MANAGE'), requireTenantContext, (req, res) => {
  const customerId = Number(req.params.id);
  const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(customerId);
  if (!customer || customer.owner_user_id !== req.user.id) {
    return res.status(404).render('forbidden', { message: 'Nem talalhato ugyfel.' });
  }

  const name = (req.body.name || '').trim();
  const email = (req.body.email || '').trim();
  const phone = (req.body.phone || '').trim();
  const status = req.body.status || 'new';
  const nextFollowup = req.body.next_followup_at || null;
  const notes = (req.body.notes || '').trim();

  if (!name) {
    const interactions = db
      .prepare(
        `SELECT i.*, u.name AS user_name
         FROM interactions i
         LEFT JOIN users u ON u.id = i.user_id
         WHERE i.customer_id = ?
         ORDER BY i.created_at DESC`
      )
      .all(customerId);
    return res.render('user/customer_detail', {
      customer,
      interactions,
      error: 'Nev kotelezo.',
    });
  }

  db.prepare(
    `UPDATE customers
     SET name = ?, email = ?, phone = ?, status = ?, next_followup_at = ?, notes = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(name, email, phone, status, nextFollowup, notes, customerId);

  recordAudit(db, {
    tenantId: req.user.tenant_id,
    entityType: 'CUSTOMER',
    entityId: customerId,
    action: 'CUSTOMER_UPDATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    before: customer,
    after: { name, email, phone, status, next_followup_at: nextFollowup, notes },
  });

  return res.redirect(`/app/customers/${customerId}`);
});

app.post('/app/customers/:id/interactions', requirePermission('INTERACTION_CREATE'), requireTenantContext, (req, res) => {
  const customerId = Number(req.params.id);
  const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(customerId);
  if (!customer || customer.owner_user_id !== req.user.id) {
    return res.status(404).render('forbidden', { message: 'Nem talalhato ugyfel.' });
  }

  const type = (req.body.type || '').trim();
  const note = (req.body.note || '').trim();

  if (!type) {
    const interactions = db
      .prepare(
        `SELECT i.*, u.name AS user_name
         FROM interactions i
         LEFT JOIN users u ON u.id = i.user_id
         WHERE i.customer_id = ?
         ORDER BY i.created_at DESC`
      )
      .all(customerId);
    return res.render('user/customer_detail', {
      customer,
      interactions,
      error: 'Interakcio tipus kotelezo.',
    });
  }

  const info = db
    .prepare('INSERT INTO interactions (customer_id, user_id, type, note) VALUES (?, ?, ?, ?)')
    .run(customerId, req.user.id, type, note);

  recordAudit(db, {
    tenantId: req.user.tenant_id,
    entityType: 'INTERACTION',
    entityId: info.lastInsertRowid,
    action: 'INTERACTION_CREATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    data: { customerId, type },
  });

  return res.redirect(`/app/customers/${customerId}`);
});

// TENANT ADMIN CUSTOMER EDIT (shared)
app.get('/tenant/customers/:id', requirePermission('CUSTOMER_MANAGE'), requireTenantContext, (req, res) => {
  const customerId = Number(req.params.id);
  const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(customerId);
  if (!customer || !ensureTenantAccess(req, customer.tenant_id)) {
    return res.status(404).render('forbidden', { message: 'Nem talalhato ugyfel.' });
  }
  const interactions = db
    .prepare(
      `SELECT i.*, u.name AS user_name
       FROM interactions i
       LEFT JOIN users u ON u.id = i.user_id
       WHERE i.customer_id = ?
       ORDER BY i.created_at DESC`
    )
    .all(customerId);
  const users = db
    .prepare('SELECT id, name FROM users WHERE tenant_id = ? ORDER BY name ASC')
    .all(req.user.tenant_id);
  res.render('tenant/customer_detail', { customer, interactions, users, error: null });
});

app.post('/tenant/customers/:id/update', requirePermission('CUSTOMER_MANAGE'), requireTenantContext, (req, res) => {
  const customerId = Number(req.params.id);
  const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(customerId);
  if (!customer || !ensureTenantAccess(req, customer.tenant_id)) {
    return res.status(404).render('forbidden', { message: 'Nem talalhato ugyfel.' });
  }

  const name = (req.body.name || '').trim();
  const email = (req.body.email || '').trim();
  const phone = (req.body.phone || '').trim();
  const status = req.body.status || 'new';
  const nextFollowup = req.body.next_followup_at || null;
  const notes = (req.body.notes || '').trim();
  const ownerUserId = req.body.owner_user_id ? Number(req.body.owner_user_id) : null;

  if (!name) {
    const interactions = db
      .prepare(
        `SELECT i.*, u.name AS user_name
         FROM interactions i
         LEFT JOIN users u ON u.id = i.user_id
         WHERE i.customer_id = ?
         ORDER BY i.created_at DESC`
      )
      .all(customerId);
    const users = db
      .prepare('SELECT id, name FROM users WHERE tenant_id = ? ORDER BY name ASC')
      .all(req.user.tenant_id);
    return res.render('tenant/customer_detail', {
      customer,
      interactions,
      users,
      error: 'Nev kotelezo.',
    });
  }

  db.prepare(
    `UPDATE customers
     SET name = ?, email = ?, phone = ?, status = ?, next_followup_at = ?, notes = ?, owner_user_id = ?, updated_at = datetime('now')
     WHERE id = ?`
  ).run(name, email, phone, status, nextFollowup, notes, ownerUserId, customerId);

  recordAudit(db, {
    tenantId: req.user.tenant_id,
    entityType: 'CUSTOMER',
    entityId: customerId,
    action: 'CUSTOMER_UPDATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    before: customer,
    after: { name, email, phone, status, next_followup_at: nextFollowup, notes, owner_user_id: ownerUserId },
  });

  return res.redirect(`/tenant/customers/${customerId}`);
});

app.post('/tenant/customers/:id/interactions', requirePermission('INTERACTION_CREATE'), requireTenantContext, (req, res) => {
  const customerId = Number(req.params.id);
  const customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(customerId);
  if (!customer || !ensureTenantAccess(req, customer.tenant_id)) {
    return res.status(404).render('forbidden', { message: 'Nem talalhato ugyfel.' });
  }

  const type = (req.body.type || '').trim();
  const note = (req.body.note || '').trim();

  if (!type) {
    const interactions = db
      .prepare(
        `SELECT i.*, u.name AS user_name
         FROM interactions i
         LEFT JOIN users u ON u.id = i.user_id
         WHERE i.customer_id = ?
         ORDER BY i.created_at DESC`
      )
      .all(customerId);
    const users = db
      .prepare('SELECT id, name FROM users WHERE tenant_id = ? ORDER BY name ASC')
      .all(req.user.tenant_id);
    return res.render('tenant/customer_detail', {
      customer,
      interactions,
      users,
      error: 'Interakcio tipus kotelezo.',
    });
  }

  const info = db
    .prepare('INSERT INTO interactions (customer_id, user_id, type, note) VALUES (?, ?, ?, ?)')
    .run(customerId, req.user.id, type, note);

  recordAudit(db, {
    tenantId: req.user.tenant_id,
    entityType: 'INTERACTION',
    entityId: info.lastInsertRowid,
    action: 'INTERACTION_CREATE',
    actorUserId: req.user.id,
    actorRole: req.user.role,
    data: { customerId, type },
  });

  return res.redirect(`/tenant/customers/${customerId}`);
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).render('forbidden', { message: 'Varatlan hiba tortent.' });
});

app.use((req, res) => {
  res.status(404).render('forbidden', { message: 'Az oldal nem talalhato.' });
});

app.listen(PORT, () => {
  console.log(`CRDom mini CRM fut: http://localhost:${PORT}`);
});
